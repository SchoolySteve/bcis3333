﻿namespace _3333_BrooksS_Lab02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Front_Club3 = new System.Windows.Forms.PictureBox();
            this.Front_Dia3 = new System.Windows.Forms.PictureBox();
            this.Back_Club3 = new System.Windows.Forms.PictureBox();
            this.Front_Club4 = new System.Windows.Forms.PictureBox();
            this.Front_Spade3 = new System.Windows.Forms.PictureBox();
            this.Front_Heart3 = new System.Windows.Forms.PictureBox();
            this.Back_Club4 = new System.Windows.Forms.PictureBox();
            this.Back_Spade3 = new System.Windows.Forms.PictureBox();
            this.Back_Heart3 = new System.Windows.Forms.PictureBox();
            this.Back_Dia3 = new System.Windows.Forms.PictureBox();
            this.DisplayedCard = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Club3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Dia3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Club3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Club4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Spade3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Heart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Club4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Spade3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Heart3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Dia3)).BeginInit();
            this.SuspendLayout();
            // 
            // Front_Club3
            // 
            this.Front_Club3.Image = ((System.Drawing.Image)(resources.GetObject("Front_Club3.Image")));
            this.Front_Club3.Location = new System.Drawing.Point(41, 87);
            this.Front_Club3.Name = "Front_Club3";
            this.Front_Club3.Size = new System.Drawing.Size(50, 70);
            this.Front_Club3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Front_Club3.TabIndex = 0;
            this.Front_Club3.TabStop = false;
            this.Front_Club3.Visible = false;
            this.Front_Club3.Click += new System.EventHandler(this.Front_Club3_Click);
            // 
            // Front_Dia3
            // 
            this.Front_Dia3.Image = ((System.Drawing.Image)(resources.GetObject("Front_Dia3.Image")));
            this.Front_Dia3.Location = new System.Drawing.Point(112, 87);
            this.Front_Dia3.Name = "Front_Dia3";
            this.Front_Dia3.Size = new System.Drawing.Size(50, 70);
            this.Front_Dia3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Front_Dia3.TabIndex = 1;
            this.Front_Dia3.TabStop = false;
            this.Front_Dia3.Visible = false;
            this.Front_Dia3.Click += new System.EventHandler(this.Front_Dia3_Click);
            // 
            // Back_Club3
            // 
            this.Back_Club3.Image = ((System.Drawing.Image)(resources.GetObject("Back_Club3.Image")));
            this.Back_Club3.Location = new System.Drawing.Point(41, 87);
            this.Back_Club3.Name = "Back_Club3";
            this.Back_Club3.Size = new System.Drawing.Size(50, 70);
            this.Back_Club3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Club3.TabIndex = 2;
            this.Back_Club3.TabStop = false;
            this.Back_Club3.Click += new System.EventHandler(this.Back_Club3_Click);
            // 
            // Front_Club4
            // 
            this.Front_Club4.Image = ((System.Drawing.Image)(resources.GetObject("Front_Club4.Image")));
            this.Front_Club4.Location = new System.Drawing.Point(335, 87);
            this.Front_Club4.Name = "Front_Club4";
            this.Front_Club4.Size = new System.Drawing.Size(50, 70);
            this.Front_Club4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Front_Club4.TabIndex = 3;
            this.Front_Club4.TabStop = false;
            this.Front_Club4.Visible = false;
            this.Front_Club4.Click += new System.EventHandler(this.Front_Club4_Click);
            // 
            // Front_Spade3
            // 
            this.Front_Spade3.Image = ((System.Drawing.Image)(resources.GetObject("Front_Spade3.Image")));
            this.Front_Spade3.Location = new System.Drawing.Point(261, 87);
            this.Front_Spade3.Name = "Front_Spade3";
            this.Front_Spade3.Size = new System.Drawing.Size(50, 70);
            this.Front_Spade3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Front_Spade3.TabIndex = 4;
            this.Front_Spade3.TabStop = false;
            this.Front_Spade3.Visible = false;
            this.Front_Spade3.Click += new System.EventHandler(this.Front_Spade3_Click);
            // 
            // Front_Heart3
            // 
            this.Front_Heart3.Image = ((System.Drawing.Image)(resources.GetObject("Front_Heart3.Image")));
            this.Front_Heart3.Location = new System.Drawing.Point(188, 87);
            this.Front_Heart3.Name = "Front_Heart3";
            this.Front_Heart3.Size = new System.Drawing.Size(50, 70);
            this.Front_Heart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Front_Heart3.TabIndex = 5;
            this.Front_Heart3.TabStop = false;
            this.Front_Heart3.Visible = false;
            this.Front_Heart3.Click += new System.EventHandler(this.Front_Heart3_Click);
            // 
            // Back_Club4
            // 
            this.Back_Club4.Image = ((System.Drawing.Image)(resources.GetObject("Back_Club4.Image")));
            this.Back_Club4.Location = new System.Drawing.Point(335, 87);
            this.Back_Club4.Name = "Back_Club4";
            this.Back_Club4.Size = new System.Drawing.Size(50, 70);
            this.Back_Club4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Club4.TabIndex = 6;
            this.Back_Club4.TabStop = false;
            this.Back_Club4.Click += new System.EventHandler(this.Back_Club4_Click);
            // 
            // Back_Spade3
            // 
            this.Back_Spade3.Image = ((System.Drawing.Image)(resources.GetObject("Back_Spade3.Image")));
            this.Back_Spade3.Location = new System.Drawing.Point(261, 87);
            this.Back_Spade3.Name = "Back_Spade3";
            this.Back_Spade3.Size = new System.Drawing.Size(50, 70);
            this.Back_Spade3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Spade3.TabIndex = 7;
            this.Back_Spade3.TabStop = false;
            this.Back_Spade3.Click += new System.EventHandler(this.Back_Spade3_Click);
            // 
            // Back_Heart3
            // 
            this.Back_Heart3.Image = ((System.Drawing.Image)(resources.GetObject("Back_Heart3.Image")));
            this.Back_Heart3.Location = new System.Drawing.Point(188, 87);
            this.Back_Heart3.Name = "Back_Heart3";
            this.Back_Heart3.Size = new System.Drawing.Size(50, 70);
            this.Back_Heart3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Heart3.TabIndex = 8;
            this.Back_Heart3.TabStop = false;
            this.Back_Heart3.Click += new System.EventHandler(this.Back_Heart3_Click);
            // 
            // Back_Dia3
            // 
            this.Back_Dia3.Image = ((System.Drawing.Image)(resources.GetObject("Back_Dia3.Image")));
            this.Back_Dia3.Location = new System.Drawing.Point(112, 87);
            this.Back_Dia3.Name = "Back_Dia3";
            this.Back_Dia3.Size = new System.Drawing.Size(50, 70);
            this.Back_Dia3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Back_Dia3.TabIndex = 9;
            this.Back_Dia3.TabStop = false;
            this.Back_Dia3.Click += new System.EventHandler(this.Back_Dia3_Click);
            // 
            // DisplayedCard
            // 
            this.DisplayedCard.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisplayedCard.Location = new System.Drawing.Point(41, 178);
            this.DisplayedCard.Name = "DisplayedCard";
            this.DisplayedCard.Size = new System.Drawing.Size(344, 23);
            this.DisplayedCard.TabIndex = 10;
            this.DisplayedCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(265, 22);
            this.label1.TabIndex = 11;
            this.label1.Text = "Select a Card to See its Name";
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(163, 218);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 33);
            this.Exit.TabIndex = 12;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 270);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DisplayedCard);
            this.Controls.Add(this.Back_Dia3);
            this.Controls.Add(this.Back_Heart3);
            this.Controls.Add(this.Back_Spade3);
            this.Controls.Add(this.Back_Club4);
            this.Controls.Add(this.Front_Heart3);
            this.Controls.Add(this.Front_Spade3);
            this.Controls.Add(this.Front_Club4);
            this.Controls.Add(this.Back_Club3);
            this.Controls.Add(this.Front_Dia3);
            this.Controls.Add(this.Front_Club3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Lab 02 Card Clicker";
            ((System.ComponentModel.ISupportInitialize)(this.Front_Club3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Dia3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Club3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Club4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Spade3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Front_Heart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Club4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Spade3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Heart3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Back_Dia3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Front_Club3;
        private System.Windows.Forms.PictureBox Front_Dia3;
        private System.Windows.Forms.PictureBox Back_Club3;
        private System.Windows.Forms.PictureBox Front_Club4;
        private System.Windows.Forms.PictureBox Front_Spade3;
        private System.Windows.Forms.PictureBox Front_Heart3;
        private System.Windows.Forms.PictureBox Back_Club4;
        private System.Windows.Forms.PictureBox Back_Spade3;
        private System.Windows.Forms.PictureBox Back_Heart3;
        private System.Windows.Forms.PictureBox Back_Dia3;
        private System.Windows.Forms.Label DisplayedCard;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit;
    }
}

